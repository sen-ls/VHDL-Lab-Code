/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0xfbc00daa */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "/home/ise/Xilinx/submission_template/submit/rcs2/control.vhd";
extern char *IEEE_P_2592010699;
extern char *IEEE_P_1242562249;

char *ieee_p_1242562249_sub_1006216973935652998_1035706684(char *, char *, char *, char *, int );
unsigned char ieee_p_2592010699_sub_2763492388968962707_503743352(char *, char *, unsigned int , unsigned int );


static void work_a_3222946569_3212880686_p_0(char *t0)
{
    char t11[16];
    char *t1;
    unsigned char t2;
    char *t3;
    char *t4;
    unsigned char t5;
    unsigned char t6;
    char *t7;
    char *t8;
    char *t9;
    unsigned char t10;
    char *t12;
    char *t13;
    char *t14;
    char *t15;
    unsigned int t16;
    unsigned int t17;
    unsigned char t18;
    char *t19;
    char *t20;
    char *t21;
    char *t22;
    char *t23;
    int t24;
    int t25;
    int t26;
    int t27;
    int t28;
    int t29;
    int t30;
    char *t31;
    int t33;
    char *t34;
    char *t35;
    char *t36;
    char *t37;
    char *t38;
    char *t39;
    char *t40;
    char *t41;
    char *t42;

LAB0:    xsi_set_current_line(54, ng0);
    t1 = (t0 + 992U);
    t2 = ieee_p_2592010699_sub_2763492388968962707_503743352(IEEE_P_2592010699, t1, 0U, 0U);
    if (t2 != 0)
        goto LAB2;

LAB4:
LAB3:    t1 = (t0 + 4352);
    *((int *)t1) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(55, ng0);
    t3 = (t0 + 1352U);
    t4 = *((char **)t3);
    t5 = *((unsigned char *)t4);
    t6 = (t5 == (unsigned char)2);
    if (t6 != 0)
        goto LAB5;

LAB7:    xsi_set_current_line(67, ng0);
    t1 = (t0 + 2472U);
    t3 = *((char **)t1);
    t1 = (t0 + 7394);
    t24 = xsi_mem_cmp(t1, t3, 3U);
    if (t24 == 1)
        goto LAB17;

LAB21:    t7 = (t0 + 7397);
    t25 = xsi_mem_cmp(t7, t3, 3U);
    if (t25 == 1)
        goto LAB17;

LAB22:    t9 = (t0 + 7400);
    t26 = xsi_mem_cmp(t9, t3, 3U);
    if (t26 == 1)
        goto LAB17;

LAB23:    t13 = (t0 + 7403);
    t27 = xsi_mem_cmp(t13, t3, 3U);
    if (t27 == 1)
        goto LAB17;

LAB24:    t15 = (t0 + 7406);
    t28 = xsi_mem_cmp(t15, t3, 3U);
    if (t28 == 1)
        goto LAB17;

LAB25:    t20 = (t0 + 7409);
    t29 = xsi_mem_cmp(t20, t3, 3U);
    if (t29 == 1)
        goto LAB17;

LAB26:    t22 = (t0 + 7412);
    t30 = xsi_mem_cmp(t22, t3, 3U);
    if (t30 == 1)
        goto LAB18;

LAB27:    t31 = (t0 + 7415);
    t33 = xsi_mem_cmp(t31, t3, 3U);
    if (t33 == 1)
        goto LAB19;

LAB28:
LAB20:    xsi_set_current_line(80, ng0);

LAB16:
LAB6:    goto LAB3;

LAB5:    xsi_set_current_line(56, ng0);
    t3 = (t0 + 2472U);
    t7 = *((char **)t3);
    t3 = (t0 + 7385);
    t9 = ((IEEE_P_2592010699) + 4000);
    t10 = xsi_vhdl_lessthan(t9, t7, 3U, t3, 3U);
    if (t10 != 0)
        goto LAB8;

LAB10:    xsi_set_current_line(60, ng0);
    t1 = (t0 + 1192U);
    t3 = *((char **)t1);
    t2 = *((unsigned char *)t3);
    t5 = (t2 == (unsigned char)3);
    if (t5 != 0)
        goto LAB13;

LAB15:    xsi_set_current_line(63, ng0);
    t1 = (t0 + 7391);
    t4 = (t0 + 4512);
    t7 = (t4 + 56U);
    t8 = *((char **)t7);
    t9 = (t8 + 56U);
    t12 = *((char **)t9);
    memcpy(t12, t1, 3U);
    xsi_driver_first_trans_fast(t4);

LAB14:
LAB9:    goto LAB6;

LAB8:    xsi_set_current_line(57, ng0);
    t12 = (t0 + 2632U);
    t13 = *((char **)t12);
    t12 = (t0 + 7352U);
    t14 = ieee_p_1242562249_sub_1006216973935652998_1035706684(IEEE_P_1242562249, t11, t13, t12, 1);
    t15 = (t11 + 12U);
    t16 = *((unsigned int *)t15);
    t17 = (1U * t16);
    t18 = (3U != t17);
    if (t18 == 1)
        goto LAB11;

LAB12:    t19 = (t0 + 4448);
    t20 = (t19 + 56U);
    t21 = *((char **)t20);
    t22 = (t21 + 56U);
    t23 = *((char **)t22);
    memcpy(t23, t14, 3U);
    xsi_driver_first_trans_fast(t19);
    xsi_set_current_line(58, ng0);
    t1 = (t0 + 2632U);
    t3 = *((char **)t1);
    t1 = (t0 + 4512);
    t4 = (t1 + 56U);
    t7 = *((char **)t4);
    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t3, 3U);
    xsi_driver_first_trans_fast(t1);
    goto LAB9;

LAB11:    xsi_size_not_matching(3U, t17, 0);
    goto LAB12;

LAB13:    xsi_set_current_line(61, ng0);
    t1 = (t0 + 7388);
    t7 = (t0 + 4512);
    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    t12 = (t9 + 56U);
    t13 = *((char **)t12);
    memcpy(t13, t1, 3U);
    xsi_driver_first_trans_fast(t7);
    goto LAB14;

LAB17:    xsi_set_current_line(69, ng0);
    t34 = (t0 + 2632U);
    t35 = *((char **)t34);
    t34 = (t0 + 7352U);
    t36 = ieee_p_1242562249_sub_1006216973935652998_1035706684(IEEE_P_1242562249, t11, t35, t34, 1);
    t37 = (t11 + 12U);
    t16 = *((unsigned int *)t37);
    t17 = (1U * t16);
    t2 = (3U != t17);
    if (t2 == 1)
        goto LAB30;

LAB31:    t38 = (t0 + 4448);
    t39 = (t38 + 56U);
    t40 = *((char **)t39);
    t41 = (t40 + 56U);
    t42 = *((char **)t41);
    memcpy(t42, t36, 3U);
    xsi_driver_first_trans_fast(t38);
    xsi_set_current_line(70, ng0);
    t1 = (t0 + 2632U);
    t3 = *((char **)t1);
    t1 = (t0 + 4512);
    t4 = (t1 + 56U);
    t7 = *((char **)t4);
    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t3, 3U);
    xsi_driver_first_trans_fast(t1);
    goto LAB16;

LAB18:    xsi_set_current_line(72, ng0);
    t1 = (t0 + 7418);
    t4 = (t0 + 4512);
    t7 = (t4 + 56U);
    t8 = *((char **)t7);
    t9 = (t8 + 56U);
    t12 = *((char **)t9);
    memcpy(t12, t1, 3U);
    xsi_driver_first_trans_fast(t4);
    goto LAB16;

LAB19:    xsi_set_current_line(74, ng0);
    t1 = (t0 + 1192U);
    t3 = *((char **)t1);
    t2 = *((unsigned char *)t3);
    t5 = (t2 == (unsigned char)3);
    if (t5 != 0)
        goto LAB32;

LAB34:    xsi_set_current_line(77, ng0);
    t1 = (t0 + 7424);
    t4 = (t0 + 4512);
    t7 = (t4 + 56U);
    t8 = *((char **)t7);
    t9 = (t8 + 56U);
    t12 = *((char **)t9);
    memcpy(t12, t1, 3U);
    xsi_driver_first_trans_fast(t4);

LAB33:    goto LAB16;

LAB29:;
LAB30:    xsi_size_not_matching(3U, t17, 0);
    goto LAB31;

LAB32:    xsi_set_current_line(75, ng0);
    t1 = (t0 + 7421);
    t7 = (t0 + 4512);
    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    t12 = (t9 + 56U);
    t13 = *((char **)t12);
    memcpy(t13, t1, 3U);
    xsi_driver_first_trans_fast(t7);
    goto LAB33;

}

static void work_a_3222946569_3212880686_p_1(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    unsigned char t8;
    unsigned int t9;
    char *t10;
    char *t11;
    char *t12;
    char *t13;
    char *t14;
    unsigned char t15;
    unsigned char t16;
    unsigned char t17;
    unsigned char t18;
    unsigned int t19;
    char *t20;
    char *t21;
    char *t22;
    char *t23;
    char *t24;
    char *t25;

LAB0:    xsi_set_current_line(89, ng0);
    t1 = (t0 + 4576);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t1);
    xsi_set_current_line(90, ng0);
    t1 = (t0 + 4640);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t1);
    xsi_set_current_line(91, ng0);
    t1 = (t0 + 4704);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t1);
    xsi_set_current_line(92, ng0);
    t1 = (t0 + 4768);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t1);
    xsi_set_current_line(93, ng0);
    t1 = (t0 + 7427);
    t3 = (t0 + 4832);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    memcpy(t7, t1, 2U);
    xsi_driver_first_trans_fast_port(t3);
    xsi_set_current_line(94, ng0);
    t1 = (t0 + 7429);
    t3 = (t0 + 4896);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    memcpy(t7, t1, 2U);
    xsi_driver_first_trans_fast_port(t3);
    xsi_set_current_line(96, ng0);
    t1 = (t0 + 2472U);
    t2 = *((char **)t1);
    t1 = (t0 + 7431);
    t8 = 1;
    if (3U == 3U)
        goto LAB5;

LAB6:    t8 = 0;

LAB7:    if (t8 != 0)
        goto LAB2;

LAB4:    t1 = (t0 + 2472U);
    t2 = *((char **)t1);
    t1 = (t0 + 7436);
    t8 = 1;
    if (3U == 3U)
        goto LAB13;

LAB14:    t8 = 0;

LAB15:    if (t8 != 0)
        goto LAB11;

LAB12:    t1 = (t0 + 2472U);
    t2 = *((char **)t1);
    t1 = (t0 + 7441);
    t8 = 1;
    if (3U == 3U)
        goto LAB21;

LAB22:    t8 = 0;

LAB23:    if (t8 != 0)
        goto LAB19;

LAB20:    t1 = (t0 + 2472U);
    t2 = *((char **)t1);
    t1 = (t0 + 7446);
    t8 = 1;
    if (3U == 3U)
        goto LAB29;

LAB30:    t8 = 0;

LAB31:    if (t8 != 0)
        goto LAB27;

LAB28:    t1 = (t0 + 2472U);
    t2 = *((char **)t1);
    t1 = (t0 + 7451);
    t8 = 1;
    if (3U == 3U)
        goto LAB37;

LAB38:    t8 = 0;

LAB39:    if (t8 != 0)
        goto LAB35;

LAB36:    t1 = (t0 + 2472U);
    t2 = *((char **)t1);
    t1 = (t0 + 7456);
    t8 = 1;
    if (3U == 3U)
        goto LAB45;

LAB46:    t8 = 0;

LAB47:    if (t8 != 0)
        goto LAB43;

LAB44:    t1 = (t0 + 2472U);
    t2 = *((char **)t1);
    t1 = (t0 + 7461);
    t8 = 1;
    if (3U == 3U)
        goto LAB53;

LAB54:    t8 = 0;

LAB55:    if (t8 != 0)
        goto LAB51;

LAB52:    t1 = (t0 + 2472U);
    t2 = *((char **)t1);
    t1 = (t0 + 7466);
    t8 = 1;
    if (3U == 3U)
        goto LAB61;

LAB62:    t8 = 0;

LAB63:    if (t8 != 0)
        goto LAB59;

LAB60:
LAB3:    xsi_set_current_line(118, ng0);
    t1 = (t0 + 1352U);
    t2 = *((char **)t1);
    t8 = *((unsigned char *)t2);
    t15 = (t8 == (unsigned char)2);
    if (t15 != 0)
        goto LAB67;

LAB69:    xsi_set_current_line(130, ng0);
    t1 = (t0 + 2472U);
    t2 = *((char **)t1);
    t1 = (t0 + 7503);
    t15 = 1;
    if (3U == 3U)
        goto LAB145;

LAB146:    t15 = 0;

LAB147:    if (t15 == 1)
        goto LAB142;

LAB143:    t6 = (t0 + 2472U);
    t7 = *((char **)t6);
    t6 = (t0 + 7506);
    t16 = 1;
    if (3U == 3U)
        goto LAB151;

LAB152:    t16 = 0;

LAB153:    t8 = t16;

LAB144:    if (t8 != 0)
        goto LAB139;

LAB141:    t1 = (t0 + 2472U);
    t2 = *((char **)t1);
    t1 = (t0 + 7511);
    t15 = 1;
    if (3U == 3U)
        goto LAB162;

LAB163:    t15 = 0;

LAB164:    if (t15 == 1)
        goto LAB159;

LAB160:    t6 = (t0 + 2472U);
    t7 = *((char **)t6);
    t6 = (t0 + 7514);
    t16 = 1;
    if (3U == 3U)
        goto LAB168;

LAB169:    t16 = 0;

LAB170:    t8 = t16;

LAB161:    if (t8 != 0)
        goto LAB157;

LAB158:    t1 = (t0 + 2472U);
    t2 = *((char **)t1);
    t1 = (t0 + 7519);
    t15 = 1;
    if (3U == 3U)
        goto LAB179;

LAB180:    t15 = 0;

LAB181:    if (t15 == 1)
        goto LAB176;

LAB177:    t6 = (t0 + 2472U);
    t7 = *((char **)t6);
    t6 = (t0 + 7522);
    t16 = 1;
    if (3U == 3U)
        goto LAB185;

LAB186:    t16 = 0;

LAB187:    t8 = t16;

LAB178:    if (t8 != 0)
        goto LAB174;

LAB175:    t1 = (t0 + 2472U);
    t2 = *((char **)t1);
    t1 = (t0 + 7527);
    t15 = 1;
    if (3U == 3U)
        goto LAB196;

LAB197:    t15 = 0;

LAB198:    if (t15 == 1)
        goto LAB193;

LAB194:    t6 = (t0 + 2472U);
    t7 = *((char **)t6);
    t6 = (t0 + 7530);
    t16 = 1;
    if (3U == 3U)
        goto LAB202;

LAB203:    t16 = 0;

LAB204:    t8 = t16;

LAB195:    if (t8 != 0)
        goto LAB191;

LAB192:
LAB140:
LAB68:    t1 = (t0 + 4368);
    *((int *)t1) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(97, ng0);
    t6 = (t0 + 4576);
    t7 = (t6 + 56U);
    t10 = *((char **)t7);
    t11 = (t10 + 56U);
    t12 = *((char **)t11);
    *((unsigned char *)t12) = (unsigned char)3;
    xsi_driver_first_trans_fast_port(t6);
    xsi_set_current_line(98, ng0);
    t1 = (t0 + 7434);
    t3 = (t0 + 4832);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    memcpy(t7, t1, 2U);
    xsi_driver_first_trans_fast_port(t3);
    goto LAB3;

LAB5:    t9 = 0;

LAB8:    if (t9 < 3U)
        goto LAB9;
    else
        goto LAB7;

LAB9:    t4 = (t2 + t9);
    t5 = (t1 + t9);
    if (*((unsigned char *)t4) != *((unsigned char *)t5))
        goto LAB6;

LAB10:    t9 = (t9 + 1);
    goto LAB8;

LAB11:    xsi_set_current_line(100, ng0);
    t6 = (t0 + 7439);
    t10 = (t0 + 4832);
    t11 = (t10 + 56U);
    t12 = *((char **)t11);
    t13 = (t12 + 56U);
    t14 = *((char **)t13);
    memcpy(t14, t6, 2U);
    xsi_driver_first_trans_fast_port(t10);
    goto LAB3;

LAB13:    t9 = 0;

LAB16:    if (t9 < 3U)
        goto LAB17;
    else
        goto LAB15;

LAB17:    t4 = (t2 + t9);
    t5 = (t1 + t9);
    if (*((unsigned char *)t4) != *((unsigned char *)t5))
        goto LAB14;

LAB18:    t9 = (t9 + 1);
    goto LAB16;

LAB19:    xsi_set_current_line(102, ng0);
    t6 = (t0 + 4640);
    t7 = (t6 + 56U);
    t10 = *((char **)t7);
    t11 = (t10 + 56U);
    t12 = *((char **)t11);
    *((unsigned char *)t12) = (unsigned char)3;
    xsi_driver_first_trans_fast_port(t6);
    xsi_set_current_line(103, ng0);
    t1 = (t0 + 7444);
    t3 = (t0 + 4832);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    memcpy(t7, t1, 2U);
    xsi_driver_first_trans_fast_port(t3);
    goto LAB3;

LAB21:    t9 = 0;

LAB24:    if (t9 < 3U)
        goto LAB25;
    else
        goto LAB23;

LAB25:    t4 = (t2 + t9);
    t5 = (t1 + t9);
    if (*((unsigned char *)t4) != *((unsigned char *)t5))
        goto LAB22;

LAB26:    t9 = (t9 + 1);
    goto LAB24;

LAB27:    xsi_set_current_line(105, ng0);
    t6 = (t0 + 7449);
    t10 = (t0 + 4832);
    t11 = (t10 + 56U);
    t12 = *((char **)t11);
    t13 = (t12 + 56U);
    t14 = *((char **)t13);
    memcpy(t14, t6, 2U);
    xsi_driver_first_trans_fast_port(t10);
    goto LAB3;

LAB29:    t9 = 0;

LAB32:    if (t9 < 3U)
        goto LAB33;
    else
        goto LAB31;

LAB33:    t4 = (t2 + t9);
    t5 = (t1 + t9);
    if (*((unsigned char *)t4) != *((unsigned char *)t5))
        goto LAB30;

LAB34:    t9 = (t9 + 1);
    goto LAB32;

LAB35:    xsi_set_current_line(107, ng0);
    t6 = (t0 + 4704);
    t7 = (t6 + 56U);
    t10 = *((char **)t7);
    t11 = (t10 + 56U);
    t12 = *((char **)t11);
    *((unsigned char *)t12) = (unsigned char)3;
    xsi_driver_first_trans_fast_port(t6);
    xsi_set_current_line(108, ng0);
    t1 = (t0 + 7454);
    t3 = (t0 + 4832);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    memcpy(t7, t1, 2U);
    xsi_driver_first_trans_fast_port(t3);
    goto LAB3;

LAB37:    t9 = 0;

LAB40:    if (t9 < 3U)
        goto LAB41;
    else
        goto LAB39;

LAB41:    t4 = (t2 + t9);
    t5 = (t1 + t9);
    if (*((unsigned char *)t4) != *((unsigned char *)t5))
        goto LAB38;

LAB42:    t9 = (t9 + 1);
    goto LAB40;

LAB43:    xsi_set_current_line(110, ng0);
    t6 = (t0 + 7459);
    t10 = (t0 + 4832);
    t11 = (t10 + 56U);
    t12 = *((char **)t11);
    t13 = (t12 + 56U);
    t14 = *((char **)t13);
    memcpy(t14, t6, 2U);
    xsi_driver_first_trans_fast_port(t10);
    goto LAB3;

LAB45:    t9 = 0;

LAB48:    if (t9 < 3U)
        goto LAB49;
    else
        goto LAB47;

LAB49:    t4 = (t2 + t9);
    t5 = (t1 + t9);
    if (*((unsigned char *)t4) != *((unsigned char *)t5))
        goto LAB46;

LAB50:    t9 = (t9 + 1);
    goto LAB48;

LAB51:    xsi_set_current_line(112, ng0);
    t6 = (t0 + 4768);
    t7 = (t6 + 56U);
    t10 = *((char **)t7);
    t11 = (t10 + 56U);
    t12 = *((char **)t11);
    *((unsigned char *)t12) = (unsigned char)3;
    xsi_driver_first_trans_fast_port(t6);
    xsi_set_current_line(113, ng0);
    t1 = (t0 + 7464);
    t3 = (t0 + 4832);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    memcpy(t7, t1, 2U);
    xsi_driver_first_trans_fast_port(t3);
    goto LAB3;

LAB53:    t9 = 0;

LAB56:    if (t9 < 3U)
        goto LAB57;
    else
        goto LAB55;

LAB57:    t4 = (t2 + t9);
    t5 = (t1 + t9);
    if (*((unsigned char *)t4) != *((unsigned char *)t5))
        goto LAB54;

LAB58:    t9 = (t9 + 1);
    goto LAB56;

LAB59:    xsi_set_current_line(115, ng0);
    t6 = (t0 + 7469);
    t10 = (t0 + 4832);
    t11 = (t10 + 56U);
    t12 = *((char **)t11);
    t13 = (t12 + 56U);
    t14 = *((char **)t13);
    memcpy(t14, t6, 2U);
    xsi_driver_first_trans_fast_port(t10);
    goto LAB3;

LAB61:    t9 = 0;

LAB64:    if (t9 < 3U)
        goto LAB65;
    else
        goto LAB63;

LAB65:    t4 = (t2 + t9);
    t5 = (t1 + t9);
    if (*((unsigned char *)t4) != *((unsigned char *)t5))
        goto LAB62;

LAB66:    t9 = (t9 + 1);
    goto LAB64;

LAB67:    xsi_set_current_line(119, ng0);
    t1 = (t0 + 2472U);
    t3 = *((char **)t1);
    t1 = (t0 + 7471);
    t17 = 1;
    if (3U == 3U)
        goto LAB76;

LAB77:    t17 = 0;

LAB78:    if (t17 == 1)
        goto LAB73;

LAB74:    t7 = (t0 + 2472U);
    t10 = *((char **)t7);
    t7 = (t0 + 7474);
    t18 = 1;
    if (3U == 3U)
        goto LAB82;

LAB83:    t18 = 0;

LAB84:    t16 = t18;

LAB75:    if (t16 != 0)
        goto LAB70;

LAB72:    t1 = (t0 + 2472U);
    t2 = *((char **)t1);
    t1 = (t0 + 7479);
    t15 = 1;
    if (3U == 3U)
        goto LAB93;

LAB94:    t15 = 0;

LAB95:    if (t15 == 1)
        goto LAB90;

LAB91:    t6 = (t0 + 2472U);
    t7 = *((char **)t6);
    t6 = (t0 + 7482);
    t16 = 1;
    if (3U == 3U)
        goto LAB99;

LAB100:    t16 = 0;

LAB101:    t8 = t16;

LAB92:    if (t8 != 0)
        goto LAB88;

LAB89:    t1 = (t0 + 2472U);
    t2 = *((char **)t1);
    t1 = (t0 + 7487);
    t15 = 1;
    if (3U == 3U)
        goto LAB110;

LAB111:    t15 = 0;

LAB112:    if (t15 == 1)
        goto LAB107;

LAB108:    t6 = (t0 + 2472U);
    t7 = *((char **)t6);
    t6 = (t0 + 7490);
    t16 = 1;
    if (3U == 3U)
        goto LAB116;

LAB117:    t16 = 0;

LAB118:    t8 = t16;

LAB109:    if (t8 != 0)
        goto LAB105;

LAB106:    t1 = (t0 + 2472U);
    t2 = *((char **)t1);
    t1 = (t0 + 7495);
    t15 = 1;
    if (3U == 3U)
        goto LAB127;

LAB128:    t15 = 0;

LAB129:    if (t15 == 1)
        goto LAB124;

LAB125:    t6 = (t0 + 2472U);
    t7 = *((char **)t6);
    t6 = (t0 + 7498);
    t16 = 1;
    if (3U == 3U)
        goto LAB133;

LAB134:    t16 = 0;

LAB135:    t8 = t16;

LAB126:    if (t8 != 0)
        goto LAB122;

LAB123:
LAB71:    goto LAB68;

LAB70:    xsi_set_current_line(120, ng0);
    t14 = (t0 + 7477);
    t21 = (t0 + 4896);
    t22 = (t21 + 56U);
    t23 = *((char **)t22);
    t24 = (t23 + 56U);
    t25 = *((char **)t24);
    memcpy(t25, t14, 2U);
    xsi_driver_first_trans_fast_port(t21);
    goto LAB71;

LAB73:    t16 = (unsigned char)1;
    goto LAB75;

LAB76:    t9 = 0;

LAB79:    if (t9 < 3U)
        goto LAB80;
    else
        goto LAB78;

LAB80:    t5 = (t3 + t9);
    t6 = (t1 + t9);
    if (*((unsigned char *)t5) != *((unsigned char *)t6))
        goto LAB77;

LAB81:    t9 = (t9 + 1);
    goto LAB79;

LAB82:    t19 = 0;

LAB85:    if (t19 < 3U)
        goto LAB86;
    else
        goto LAB84;

LAB86:    t12 = (t10 + t19);
    t13 = (t7 + t19);
    if (*((unsigned char *)t12) != *((unsigned char *)t13))
        goto LAB83;

LAB87:    t19 = (t19 + 1);
    goto LAB85;

LAB88:    xsi_set_current_line(122, ng0);
    t13 = (t0 + 7485);
    t20 = (t0 + 4896);
    t21 = (t20 + 56U);
    t22 = *((char **)t21);
    t23 = (t22 + 56U);
    t24 = *((char **)t23);
    memcpy(t24, t13, 2U);
    xsi_driver_first_trans_fast_port(t20);
    goto LAB71;

LAB90:    t8 = (unsigned char)1;
    goto LAB92;

LAB93:    t9 = 0;

LAB96:    if (t9 < 3U)
        goto LAB97;
    else
        goto LAB95;

LAB97:    t4 = (t2 + t9);
    t5 = (t1 + t9);
    if (*((unsigned char *)t4) != *((unsigned char *)t5))
        goto LAB94;

LAB98:    t9 = (t9 + 1);
    goto LAB96;

LAB99:    t19 = 0;

LAB102:    if (t19 < 3U)
        goto LAB103;
    else
        goto LAB101;

LAB103:    t11 = (t7 + t19);
    t12 = (t6 + t19);
    if (*((unsigned char *)t11) != *((unsigned char *)t12))
        goto LAB100;

LAB104:    t19 = (t19 + 1);
    goto LAB102;

LAB105:    xsi_set_current_line(124, ng0);
    t13 = (t0 + 7493);
    t20 = (t0 + 4896);
    t21 = (t20 + 56U);
    t22 = *((char **)t21);
    t23 = (t22 + 56U);
    t24 = *((char **)t23);
    memcpy(t24, t13, 2U);
    xsi_driver_first_trans_fast_port(t20);
    goto LAB71;

LAB107:    t8 = (unsigned char)1;
    goto LAB109;

LAB110:    t9 = 0;

LAB113:    if (t9 < 3U)
        goto LAB114;
    else
        goto LAB112;

LAB114:    t4 = (t2 + t9);
    t5 = (t1 + t9);
    if (*((unsigned char *)t4) != *((unsigned char *)t5))
        goto LAB111;

LAB115:    t9 = (t9 + 1);
    goto LAB113;

LAB116:    t19 = 0;

LAB119:    if (t19 < 3U)
        goto LAB120;
    else
        goto LAB118;

LAB120:    t11 = (t7 + t19);
    t12 = (t6 + t19);
    if (*((unsigned char *)t11) != *((unsigned char *)t12))
        goto LAB117;

LAB121:    t19 = (t19 + 1);
    goto LAB119;

LAB122:    xsi_set_current_line(126, ng0);
    t13 = (t0 + 7501);
    t20 = (t0 + 4896);
    t21 = (t20 + 56U);
    t22 = *((char **)t21);
    t23 = (t22 + 56U);
    t24 = *((char **)t23);
    memcpy(t24, t13, 2U);
    xsi_driver_first_trans_fast_port(t20);
    goto LAB71;

LAB124:    t8 = (unsigned char)1;
    goto LAB126;

LAB127:    t9 = 0;

LAB130:    if (t9 < 3U)
        goto LAB131;
    else
        goto LAB129;

LAB131:    t4 = (t2 + t9);
    t5 = (t1 + t9);
    if (*((unsigned char *)t4) != *((unsigned char *)t5))
        goto LAB128;

LAB132:    t9 = (t9 + 1);
    goto LAB130;

LAB133:    t19 = 0;

LAB136:    if (t19 < 3U)
        goto LAB137;
    else
        goto LAB135;

LAB137:    t11 = (t7 + t19);
    t12 = (t6 + t19);
    if (*((unsigned char *)t11) != *((unsigned char *)t12))
        goto LAB134;

LAB138:    t19 = (t19 + 1);
    goto LAB136;

LAB139:    xsi_set_current_line(131, ng0);
    t13 = (t0 + 7509);
    t20 = (t0 + 4896);
    t21 = (t20 + 56U);
    t22 = *((char **)t21);
    t23 = (t22 + 56U);
    t24 = *((char **)t23);
    memcpy(t24, t13, 2U);
    xsi_driver_first_trans_fast_port(t20);
    goto LAB140;

LAB142:    t8 = (unsigned char)1;
    goto LAB144;

LAB145:    t9 = 0;

LAB148:    if (t9 < 3U)
        goto LAB149;
    else
        goto LAB147;

LAB149:    t4 = (t2 + t9);
    t5 = (t1 + t9);
    if (*((unsigned char *)t4) != *((unsigned char *)t5))
        goto LAB146;

LAB150:    t9 = (t9 + 1);
    goto LAB148;

LAB151:    t19 = 0;

LAB154:    if (t19 < 3U)
        goto LAB155;
    else
        goto LAB153;

LAB155:    t11 = (t7 + t19);
    t12 = (t6 + t19);
    if (*((unsigned char *)t11) != *((unsigned char *)t12))
        goto LAB152;

LAB156:    t19 = (t19 + 1);
    goto LAB154;

LAB157:    xsi_set_current_line(133, ng0);
    t13 = (t0 + 7517);
    t20 = (t0 + 4896);
    t21 = (t20 + 56U);
    t22 = *((char **)t21);
    t23 = (t22 + 56U);
    t24 = *((char **)t23);
    memcpy(t24, t13, 2U);
    xsi_driver_first_trans_fast_port(t20);
    goto LAB140;

LAB159:    t8 = (unsigned char)1;
    goto LAB161;

LAB162:    t9 = 0;

LAB165:    if (t9 < 3U)
        goto LAB166;
    else
        goto LAB164;

LAB166:    t4 = (t2 + t9);
    t5 = (t1 + t9);
    if (*((unsigned char *)t4) != *((unsigned char *)t5))
        goto LAB163;

LAB167:    t9 = (t9 + 1);
    goto LAB165;

LAB168:    t19 = 0;

LAB171:    if (t19 < 3U)
        goto LAB172;
    else
        goto LAB170;

LAB172:    t11 = (t7 + t19);
    t12 = (t6 + t19);
    if (*((unsigned char *)t11) != *((unsigned char *)t12))
        goto LAB169;

LAB173:    t19 = (t19 + 1);
    goto LAB171;

LAB174:    xsi_set_current_line(135, ng0);
    t13 = (t0 + 7525);
    t20 = (t0 + 4896);
    t21 = (t20 + 56U);
    t22 = *((char **)t21);
    t23 = (t22 + 56U);
    t24 = *((char **)t23);
    memcpy(t24, t13, 2U);
    xsi_driver_first_trans_fast_port(t20);
    goto LAB140;

LAB176:    t8 = (unsigned char)1;
    goto LAB178;

LAB179:    t9 = 0;

LAB182:    if (t9 < 3U)
        goto LAB183;
    else
        goto LAB181;

LAB183:    t4 = (t2 + t9);
    t5 = (t1 + t9);
    if (*((unsigned char *)t4) != *((unsigned char *)t5))
        goto LAB180;

LAB184:    t9 = (t9 + 1);
    goto LAB182;

LAB185:    t19 = 0;

LAB188:    if (t19 < 3U)
        goto LAB189;
    else
        goto LAB187;

LAB189:    t11 = (t7 + t19);
    t12 = (t6 + t19);
    if (*((unsigned char *)t11) != *((unsigned char *)t12))
        goto LAB186;

LAB190:    t19 = (t19 + 1);
    goto LAB188;

LAB191:    xsi_set_current_line(137, ng0);
    t13 = (t0 + 7533);
    t20 = (t0 + 4896);
    t21 = (t20 + 56U);
    t22 = *((char **)t21);
    t23 = (t22 + 56U);
    t24 = *((char **)t23);
    memcpy(t24, t13, 2U);
    xsi_driver_first_trans_fast_port(t20);
    goto LAB140;

LAB193:    t8 = (unsigned char)1;
    goto LAB195;

LAB196:    t9 = 0;

LAB199:    if (t9 < 3U)
        goto LAB200;
    else
        goto LAB198;

LAB200:    t4 = (t2 + t9);
    t5 = (t1 + t9);
    if (*((unsigned char *)t4) != *((unsigned char *)t5))
        goto LAB197;

LAB201:    t9 = (t9 + 1);
    goto LAB199;

LAB202:    t19 = 0;

LAB205:    if (t19 < 3U)
        goto LAB206;
    else
        goto LAB204;

LAB206:    t11 = (t7 + t19);
    t12 = (t6 + t19);
    if (*((unsigned char *)t11) != *((unsigned char *)t12))
        goto LAB203;

LAB207:    t19 = (t19 + 1);
    goto LAB205;

}


extern void work_a_3222946569_3212880686_init()
{
	static char *pe[] = {(void *)work_a_3222946569_3212880686_p_0,(void *)work_a_3222946569_3212880686_p_1};
	xsi_register_didat("work_a_3222946569_3212880686", "isim/clockedround_isim_beh.exe.sim/work/a_3222946569_3212880686.didat");
	xsi_register_executes(pe);
}
